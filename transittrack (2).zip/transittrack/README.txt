TransitTrack - smart public transportation prototype

How to run
1. Unzip this folder.
2. Open index.html in any modern browser (Chrome, Edge, Firefox, Safari).
   An internet connection is only needed to load the Roboto font; the app works without it.

Demo accounts (password: demo1234)
- passenger@demo.in
- conductor@demo.in
New conductor accounts need the staff code BUS-2026.

Notes
- GPS, crowd and historical delay data are simulated in the browser.
- Accounts and conductor updates are stored in the browser (localStorage).
  Open a passenger tab and a conductor tab in the same browser to see updates shared between them.
